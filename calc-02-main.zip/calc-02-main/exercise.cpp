#include <iostream>
#include "Calculadora.hpp"

int main() 
{
  Calculadora calc(6,3);
  std::cout << "CALCULADORA ARITMETICA" << std::endl;
  std::cout << "======================" << std::endl;

  std::cout << "Suma: " << calc.sumar() << std::endl;
}
