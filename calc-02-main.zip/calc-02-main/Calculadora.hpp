#pragma once   // Solo se compila una vez

class Calculadora {
public:
    Calculadora();
    Calculadora(int, int);
    ~Calculadora(); // Destructor
    int sumar();
    int restar();
    int multiplicar();
    int dividir();
private:
    int a;
    int b;
};