#include "Calculadora.hpp"

/**
 * @brief Constructor por defecto de la clase Calculadora.
 * Inicializa los atributos a y b con el valor 0.
 */
Calculadora::Calculadora() {
    a = 0;
    b = 0;
}

/**
 * @brief Constructor de la clase Calculadora.
 * @param num1 Primer número de la operación.
 * @param num2 Segundo número de la operación.
 * Inicializa los atributos a y b con los valores num1 y num2 respectivamente.
 */
Calculadora::Calculadora(int num1, int num2) {
    a = num1;
    b = num2;
}

Calculadora::~Calculadora() {
}

int Calculadora::sumar() {
    return 0;
}

int Calculadora::restar() {
    return 0;
}

int Calculadora::multiplicar() {
    return 0;
}

int Calculadora::dividir() {
    return 0;
}